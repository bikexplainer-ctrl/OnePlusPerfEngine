#!/usr/bin/env python3
"""Offline frame-time analysis. Mirrors FrameStatsAnalyzer.kt (same definitions).
Usage: analyze_frames.py <bench_dir | frames_raw.txt> [--target 120]
Input: concatenated `dumpsys SurfaceFlinger --latency` outputs (header line + desired/actual/ready rows)."""
import sys, math, argparse, os

def parse(text):
    present = set()
    for ln in text.splitlines():
        f = ln.split()
        if len(f) == 3 and all(x.lstrip('-').isdigit() for x in f):
            a = int(f[1])
            if 0 < a < 2**63 - 1:
                present.add(a)
    return sorted(present)

def analyze(ts, target):
    iv = [(b - a) / 1e6 for a, b in zip(ts, ts[1:]) if 0 < (b - a) / 1e6 < 1000]
    if len(iv) < 9:
        return None
    mean = sum(iv) / len(iv)
    desc = sorted(iv, reverse=True)
    n = max(1, math.ceil(len(iv) * 0.01))
    worst = sum(desc[:n]) / n
    tgt = 1000.0 / target
    var = sum((x - mean) ** 2 for x in iv) / len(iv)
    return dict(frames=len(iv) + 1, avg_fps=1000 / mean, one_pct_low_fps=1000 / worst,
                p99_ms=desc[min(len(desc) - 1, n - 1)], mean_ms=mean, jitter_ms=math.sqrt(var),
                drops=sum(x > 1.5 * tgt for x in iv), drop_pct=100 * sum(x > 1.5 * tgt for x in iv) / len(iv),
                stability_pct=100 * sum(x <= 1.25 * tgt for x in iv) / len(iv))

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("--target", type=int, default=120)
    a = ap.parse_args()
    p = os.path.join(a.path, "frames_raw.txt") if os.path.isdir(a.path) else a.path
    r = analyze(parse(open(p).read()), a.target)
    if not r: sys.exit("not enough frames")
    for k, v in r.items(): print(f"{k:16s} {v:.2f}")
