# OnePlus 15R — Hardware & Compatibility Report

Status key: **VERIFIED** = from a cited public source. **UNVERIFIED** = general Android/Qualcomm knowledge or not yet confirmed on your unit; confirm with `docs/ADB_COMMANDS.md`. Nothing below was measured on a physical 15R (this report was prepared without device access).

## 1. Identified hardware (VERIFIED, public specs)

| Item | Value | Source |
|---|---|---|
| Chipset | Qualcomm SM8845 Snapdragon 8 Gen 5, 3 nm | GSMArena |
| CPU | 8 cores: 2 × 3.8 GHz (Oryon V3 "Phoenix L") + 6 × 3.32 GHz (Oryon V3 "Phoenix M") | GSMArena |
| GPU | Adreno 829 | GSMArena |
| RAM / storage | 12 GB; UFS 4.1, 256/512 GB | GSMArena |
| Display | 6.83" AMOLED, 1272×2800, up to 165 Hz | GSMArena; OnePlus site ("165Hz 1.5K") |
| Battery / charging | 7400 mAh Si/C, 80 W wired (SUPERVOOC) | GSMArena; OnePlus site |
| OS | Android 16 / OxygenOS 16 | GSMArena; OnePlus site |
| Models | CPH2767, CPH2769 | GSMArena |
| Cooling hardware | Not stated on the pages read: **UNVERIFIED** | — |

Sources: https://www.gsmarena.com/oneplus_15r_5g-14358.php · https://www.oneplus.com/global/15r/specs

Not to be confused: the OnePlus **15** uses a different SoC (SM8850). Custom-kernel/rooting threads found for the 15 do **not** apply to the 15R.

## 2. Kernel & firmware capabilities

| Question | Status |
|---|---|
| Kernel version on your unit | Unknown here. Run `adb shell uname -a`. Android 16 devices normally ship GKI 6.x kernels (UNVERIFIED for 15R). |
| Kernel source / custom kernel for 15R | **UNVERIFIED** — none confirmed. Do not assume one exists. |
| Bootloader unlock on 15R | **UNVERIFIED.** Reports exist for the OnePlus 15 (unlock via an in-device "test app"); no 15R-specific confirmation found. Unlocking wipes data and may affect warranty/banking/Play Integrity. |
| Root | Requires a path you establish yourself (e.g., Magisk/KernelSU after unlock). Not provided or endorsed by this project. |
| Verified boot state | Read: `adb shell getprop ro.boot.verifiedbootstate ro.boot.flash.locked` |

## 3. Readable vs writable (non-root vs root)

Legend: R = readable by a normal app, R(adb) = readable via `adb shell` (shell SELinux domain) but usually not by an app, W(root) = writable only by root, – = no supported interface.

| Parameter | Interface | Normal app | adb shell | Root | Restriction class | Notes |
|---|---|---|---|---|---|---|
| CPU per-core current freq | `/sys/devices/system/cpu/cpuN/cpufreq/scaling_cur_freq` | R if SELinux permits (UNVERIFIED) | R | R | — | App reports N/A if blocked |
| Policy min/max/ceiling | `…/cpufreq/policyN/{cpuinfo_*_freq,scaling_*_freq}` | R (UNVERIFIED) | R | **W(root)** | B kernel | Ceiling may be lowered by thermal/perf HAL |
| Hardware max freq | `cpuinfo_max_freq` | R | R | read-only | **D hardware/firmware OPP** | Not tunable |
| Governor | `scaling_governor` | R | R | W(root) among `scaling_available_governors` | B | Vendor services may override |
| Per-core utilisation | `/proc/stat` | usually blocked | R | R | A/B (SELinux) | |
| Core parking / hotplug | `cpuN/online`, core_ctl | partial | R | W(root) but unsupported here | B | Observe only |
| Thermal zones | `/sys/class/thermal/thermal_zone*/{type,temp}` | often blocked | R | R | C | Zone names are vendor-specific |
| OS thermal status / headroom | `PowerManager` APIs | **R (official)** | R | R | A | Public API, always available |
| Battery temp/voltage/current/health | `BatteryManager` | **R (official)** | R | R | A | Current sign is OEM-specific |
| GPU freq/busy/temp | `/sys/class/kgsl/kgsl-3d0/*` | often blocked (UNVERIFIED) | R (UNVERIFIED) | R/W | B | Node names unconfirmed on 15R |
| RAM, low-memory | `ActivityManager`, `/proc/meminfo` | **R** | R | R | A | |
| Memory PSI | `/proc/pressure/memory` | usually blocked | R | R | B | |
| Other apps' CPU/RAM | `top`, `/proc/<pid>` | **not possible** (hidepid/SELinux) | R | R | A | Usage Access gives foreground time only |
| Other app's frame timing | `dumpsys SurfaceFlinger --latency` | not possible | R | R | A/B | Only via adb/root |
| Voltage control | none standard | – | – | – | **C/D (PMIC/RPMh firmware)** | Not implemented |
| Thermal trip points / emergency shutdown | firmware/kernel | – | – | – | **C** | Never touched |

## 4. Restriction analysis (A/B/C/D)

| Restriction | Class | Safely modifiable? | Requirement |
|---|---|---|---|
| Battery saver, background limits, OxygenOS game/perf modes, refresh-rate policy | A Android software | **Yes** | Use Settings / Game Assistant (user-controlled) |
| CPU frequency ceiling below OPP max | B | Yes, within OPP | Root. Vendor perf HAL may reset it |
| Governor selection | B | Yes, among kernel-provided | Root |
| Core parking, scheduler tunables (WALT/core_ctl, if present) | B | Possible but **not implemented** (undocumented per-device) | Root |
| Frequencies above the OPP table (overclock) | D (OPP+voltage tables in firmware/DT) | **No** on stock kernel | A custom kernel with additional OPPs *and* validated voltage; availability for 15R unverified; not provided here |
| Thermal throttling engine | C (vendor thermal HAL + kernel) | Technically alterable only by disabling safety → **refused** | — |
| Battery/charger protection, emergency shutdown | C/D | **No** | — |
| Voltage | C/D | **No** | — |

## 5. Overclocking feasibility

- **CPU**: Not supported on a stock kernel. `cpuinfo_max_freq` is set by the OPP table; `scaling_max_freq` can't exceed it. Supporting 3.8/3.32 GHz+ would need extra OPP entries with matching voltages — a firmware/devicetree/kernel matter, and no such kernel has been verified for the 15R. This project's root module **rejects any value above `cpuinfo_max_freq` or not in the kernel's own table**.
- **GPU**: Same structure (kgsl OPP table). Read-only in this app.
- **Voltage**: No standard writable interface; not implemented.
- **Thermal config**: Not modified, by design.
- **Scheduler optimisation**: No safe, documented, device-verified knobs identified; not implemented.

Risks of overclocking (why it is excluded): voltage/frequency mismatch → instability, data corruption, silicon degradation; higher heat on a thin phone chassis → earlier throttling (often *lower* sustained FPS); battery stress; possible warranty loss. For gaming, **sustained** performance is thermally limited, so raising peaks usually doesn't raise sustained frame rate.

## 6. Best achievable configuration (no overclock)

1. Measure first (Game tab / `tools/`) — establish avg, 1% low, throttle onset time over ≥15 min.
2. Use supported software settings (Game Assistant performance mode, battery saver off, in-game preset one notch down, FPS cap that holds).
3. Compare a **locked 90 fps** run to 120: if 120 shows throttling dips, 90 often gives better 1% lows.
4. Reduce heat inputs: no charging during play, no thick case, cool ambient.
5. Optional (root): a slightly lower prime-cluster ceiling can reduce thermal ramp; keep it only if repeatable benchmarks show better sustained 1% lows.

## 7. Open items to verify on your device
Kernel version, `/proc/stat` and kgsl readability for apps, thermal-zone names, whether `dumpsys SurfaceFlinger --latency` still behaves as documented on OxygenOS 16, bootloader unlockability. Commands are in `docs/ADB_COMMANDS.md`; paste results back to update this matrix.
