# OPR Perf Engine — OnePlus 15R diagnostics & sustained-performance analyser

Kotlin + Jetpack Compose + NDK (C++) + Room + foreground service. Non-root first; a separate, confirmation-gated root module.

> **Status: source written without a device or a Gradle build in the authoring environment. It has not been compiled or run.** Expect to fix a few compile errors on first sync. The frame-statistics logic is mirrored in `tools/analyze_frames.py` and was executed; the Kotlin unit tests were not.
> **No performance has been "unlocked" or improved by this project, and none is claimed.** See `docs/COMPATIBILITY_REPORT.md` for why overclocking isn't supported on a stock kernel.

## What it does
- Live read-only telemetry: SoC, per-policy and per-core CPU freq/governor, GPU (kgsl, if readable), RAM/PSI, battery (temp/V/I/health/cycles), thermal zones, Android thermal status + headroom. Every value is tagged **ACTUAL / ESTIMATE / N/A (with reason)**.
- Health levels GREEN/YELLOW/ORANGE/RED with current value, reference limit, difference, consequence, action. Component limits are **UNKNOWN** unless you set your own (labelled USER-SET) or a cited verified limit is added to `VerifiedLimits`.
- Game tab: avg FPS, 1% low, frame-time p99/jitter, drops, stability; bottleneck estimate; sustained-120 advice. Frame source = root `dumpsys SurfaceFlinger` polling or pasted adb output. Never touches game files or anti-cheat.
- Root module (optional): choose `scaling_max/min_freq` or governor **only from the kernel's own tables**, with preview → explicit confirmation → readback → auto-rollback. Refuses values above `cpuinfo_max_freq`, while throttled, or on any non-whitelisted node.
- History in Room (7-day prune).

## Project layout
```
OnePlusPerfEngine/
├─ settings.gradle.kts  build.gradle.kts  gradle.properties  gradle/wrapper/gradle-wrapper.properties
├─ app/build.gradle.kts
├─ app/src/main/AndroidManifest.xml
├─ app/src/main/cpp/            CMakeLists.txt, sysfs_reader.cpp   (read-only batched sysfs reader)
├─ app/src/main/java/dev/opr/engine/
│  ├─ data/      Models.kt (Reading<T>), Sysfs.kt, Db.kt (Room)
│  ├─ collect/   Cpu/Gpu/Thermal/Battery/Memory/System collectors
│  ├─ thermal/   HealthEvaluator.kt, ThresholdStore.kt
│  ├─ game/      FrameStats.kt, Bottleneck.kt
│  ├─ root/      RootShell.kt, RootTuner.kt, CompatProbe.kt
│  ├─ service/   MonitorService.kt, MetricsHub.kt
│  └─ ui/        Theme, Components (graphs), Screens, MainActivity, UsageRanking
├─ app/src/test/…/CoreLogicTest.kt
├─ tools/        bench_capture.sh, analyze_frames.py
└─ docs/         COMPATIBILITY_REPORT.md, ADB_COMMANDS.md, TESTING_BENCHMARKING.md
```

## Install
1. Android Studio (Ladybug+ / current stable), SDK 36, NDK + CMake 3.22 (SDK Manager).
2. Open the folder; if `gradle/wrapper/gradle-wrapper.jar` is missing, Studio offers to generate it (or run `gradle wrapper --gradle-version 8.11.1`).
3. Sync, then Run on the phone (USB debugging on). Or `./gradlew :app:assembleDebug` → `adb install -r app/build/outputs/apk/debug/app-debug.apk`.
4. First run: allow notifications; optionally Usage access (top-bar button) for foreground-time ranking.

## Root instructions
Root is not provided here. If you already have it by your own means, the app only contacts `su` when you press *Probe with root* / *Root top* / *Apply*. Superuser prompt → grant → Analysis tab shows the root panel. Android 16 SELinux and OnePlus's perf services may revert or deny writes; the app reports that instead of forcing it.

## Next steps
Run `docs/ADB_COMMANDS.md` on your phone and paste outputs: that converts the UNVERIFIED rows in the compatibility matrix into verified ones and fixes any wrong sysfs paths.

## Build APK without a PC (GitHub Actions)
1. Create a GitHub repository and upload the **contents of this folder** (not the ZIP as a single file).
2. Open the repository's **Actions** tab.
3. Select **Build OnePlus Perf Engine APK** and tap **Run workflow** (or push to `main`).
4. When the run completes, open it and download the `OnePlusPerfEngine-debug-apk` artifact.
5. Extract the downloaded artifact and install `app-debug.apk` on your phone.

The workflow builds a debug APK. It does not root the phone, unlock the bootloader, or enable overclocking. First build may expose source or toolchain errors because this project has not previously been compiled or tested.
