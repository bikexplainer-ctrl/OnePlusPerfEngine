// Why native: one sampling tick reads ~100 tiny sysfs/procfs files (per-core freq, thermal zones, kgsl).
// Doing that through java.io creates a FileInputStream + buffers per file; a single JNI call using raw
// open/read/close keeps the monitor's own CPU footprint (and therefore its effect on the measurement) small.
// READ-ONLY by construction: files are opened O_RDONLY. There is no write path in this library.
#include <jni.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <string>

extern "C" JNIEXPORT jobjectArray JNICALL
Java_dev_opr_engine_data_NativeSysfs_readFiles(JNIEnv *env, jclass, jobjectArray paths) {
    const jsize n = env->GetArrayLength(paths);
    jclass strCls = env->FindClass("java/lang/String");
    jobjectArray out = env->NewObjectArray(n, strCls, nullptr);
    char buf[4096];
    for (jsize i = 0; i < n; ++i) {
        auto jpath = (jstring) env->GetObjectArrayElement(paths, i);
        const char *path = env->GetStringUTFChars(jpath, nullptr);
        int fd = open(path, O_RDONLY | O_CLOEXEC);
        if (fd >= 0) {
            std::string data;
            ssize_t r;
            while ((r = read(fd, buf, sizeof(buf))) > 0) {
                data.append(buf, (size_t) r);
                if (data.size() > 64 * 1024) break;  // sanity cap
            }
            close(fd);
            if (r >= 0) {
                // trim trailing whitespace/newlines
                while (!data.empty() && (data.back() == '\n' || data.back() == ' ' || data.back() == '\0')) data.pop_back();
                env->SetObjectArrayElement(out, i, env->NewStringUTF(data.c_str()));
            }
        }
        env->ReleaseStringUTFChars(jpath, path);
        env->DeleteLocalRef(jpath);
    }
    return out;
}
