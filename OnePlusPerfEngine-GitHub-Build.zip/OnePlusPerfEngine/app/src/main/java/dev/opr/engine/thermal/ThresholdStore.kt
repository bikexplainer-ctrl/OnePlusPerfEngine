package dev.opr.engine.thermal

import android.content.Context
import dev.opr.engine.data.ThermalClass

/** Persists user-set thresholds. Nothing is pre-filled: unset means UNKNOWN. */
class ThresholdStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("thresholds", Context.MODE_PRIVATE)

    fun load(): Thresholds {
        val m = ThermalClass.values().filter { it != ThermalClass.OTHER }.associateWith { c ->
            ClassThresholds(get("${c.name}_y"), get("${c.name}_o"), get("${c.name}_r"))
        }
        return Thresholds(m, sp.getFloat("rising", 3f))
    }

    fun set(c: ThermalClass, y: Float?, o: Float?, r: Float?) {
        sp.edit().apply {
            put("${c.name}_y", y); put("${c.name}_o", o); put("${c.name}_r", r)
        }.apply()
    }

    private fun get(k: String): Float? = if (sp.contains(k)) sp.getFloat(k, 0f) else null
    private fun android.content.SharedPreferences.Editor.put(k: String, v: Float?) {
        if (v == null) remove(k) else putFloat(k, v)
    }
}
