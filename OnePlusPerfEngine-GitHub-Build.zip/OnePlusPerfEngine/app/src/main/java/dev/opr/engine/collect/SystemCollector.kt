package dev.opr.engine.collect

import android.content.Context
import dev.opr.engine.data.SystemSnapshot

class SystemCollector(ctx: Context) {
    private val cpu = CpuCollector()
    private val gpu = GpuCollector()
    private val thermal = ThermalCollector(ctx)
    private val battery = BatteryCollector(ctx)
    private val memory = MemoryCollector(ctx)

    fun collect(): SystemSnapshot {
        val now = System.currentTimeMillis()
        return SystemSnapshot(now, cpu.collect(), gpu.collect(), thermal.collect(now), battery.collect(), memory.collect())
    }
}
