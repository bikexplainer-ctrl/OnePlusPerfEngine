package dev.opr.engine.root

import dev.opr.engine.data.*

data class TuningChange(val path: String, val oldValue: String, val newValue: String, val reason: String)
sealed interface PlanResult {
    data class Ok(val changes: List<TuningChange>) : PlanResult
    data class Rejected(val why: String) : PlanResult
}
data class ApplyResult(val applied: List<TuningChange>, val failed: String?, val rolledBack: Boolean)

/**
 * Supported-modification module (root only). Deliberately narrow:
 *  - Only cpufreq policy nodes: scaling_max_freq, scaling_min_freq, scaling_governor.
 *  - Frequencies must be listed in the kernel's own OPP/available-frequency table and ≤ cpuinfo_max_freq.
 *    => it can never overclock; it can only choose a point inside what the vendor kernel already permits.
 *  - Governors must be in scaling_available_governors.
 *  - Refused while OS thermal status ≥ SEVERE.
 *  - Never touches thermal zones, trip points, voltage, battery/charger nodes or any undocumented interface.
 *  - Every change is previewed, needs explicit user confirmation (done in UI), is read back, and rolled back on mismatch.
 */
object RootTuner {
    private val allowedPath = Regex("^/sys/devices/system/cpu/cpufreq/policy\\d+/(scaling_max_freq|scaling_min_freq|scaling_governor)$")
    private val safeToken = Regex("^[A-Za-z0-9_.-]+$")

    fun plan(policy: CpuPolicy, wantMaxKhz: Long?, wantMinKhz: Long?, wantGovernor: String?, osThermalStatus: Int): PlanResult {
        if (osThermalStatus >= 3) return PlanResult.Rejected("Device is thermally throttled (status $osThermalStatus). Cool down before tuning.")
        val hwMax = policy.hwMaxKhz.valueOrNull() ?: return PlanResult.Rejected("hardware max frequency unreadable; refusing to guess limits")
        val freqs = policy.availableFreqsKhz.valueOrNull()
        val base = "/sys/devices/system/cpu/cpufreq/policy${policy.id}"
        val changes = mutableListOf<TuningChange>()

        fun checkFreq(f: Long, label: String): String? {
            if (f > hwMax) return "$label $f kHz exceeds cpuinfo_max_freq $hwMax. Overclocking is not supported by this module."
            if (freqs == null) return "No scaling_available_frequencies on this kernel; cannot validate $label against an OPP table."
            if (f !in freqs) return "$label $f kHz is not in the kernel's available frequency table."
            return null
        }
        wantMaxKhz?.let { f ->
            checkFreq(f, "max")?.let { return PlanResult.Rejected(it) }
            changes += TuningChange("$base/scaling_max_freq", policy.scalingMaxKhz.valueOrNull()?.toString() ?: return PlanResult.Rejected("current max unreadable"), f.toString(), "Set sustained frequency ceiling")
        }
        wantMinKhz?.let { f ->
            checkFreq(f, "min")?.let { return PlanResult.Rejected(it) }
            changes += TuningChange("$base/scaling_min_freq", policy.scalingMinKhz.valueOrNull()?.toString() ?: return PlanResult.Rejected("current min unreadable"), f.toString(), "Set frequency floor")
        }
        wantGovernor?.let { g ->
            if (!safeToken.matches(g)) return PlanResult.Rejected("invalid governor name")
            val avail = policy.availableGovernors.valueOrNull() ?: return PlanResult.Rejected("available governors unreadable")
            if (g !in avail) return PlanResult.Rejected("governor '$g' not in scaling_available_governors")
            changes += TuningChange("$base/scaling_governor", policy.governor.valueOrNull() ?: return PlanResult.Rejected("current governor unreadable"), g, "Change governor")
        }
        val newMax = wantMaxKhz ?: policy.scalingMaxKhz.valueOrNull()
        val newMin = wantMinKhz ?: policy.scalingMinKhz.valueOrNull()
        if (newMax != null && newMin != null && newMin > newMax) return PlanResult.Rejected("min ($newMin) would exceed max ($newMax)")
        if (changes.isEmpty()) return PlanResult.Rejected("nothing to change")
        for (c in changes) if (!allowedPath.matches(c.path) || !safeToken.matches(c.newValue)) return PlanResult.Rejected("path/value failed whitelist")
        return PlanResult.Ok(changes)
    }

    /** Call only after the user confirmed the exact [changes] shown in the UI. */
    fun apply(changes: List<TuningChange>): ApplyResult {
        val done = mutableListOf<TuningChange>()
        for (c in changes) {
            require(allowedPath.matches(c.path) && safeToken.matches(c.newValue)) { "whitelist violation" }
            val w = RootShell.exec("echo ${c.newValue} > ${c.path}")
            val back = RootShell.exec("cat ${c.path}").out.trim()
            if (!w.ok || back != c.newValue) {
                // Vendor perf HALs often overwrite these nodes; treat mismatch as failure and restore.
                revert(done + c)
                return ApplyResult(done, "readback mismatch at ${c.path}: wrote ${c.newValue}, read '$back' (${w.err})", true)
            }
            done += c
        }
        return ApplyResult(done, null, false)
    }

    fun revert(changes: List<TuningChange>) {
        for (c in changes.asReversed()) {
            if (allowedPath.matches(c.path) && safeToken.matches(c.oldValue)) RootShell.exec("echo ${c.oldValue} > ${c.path}")
        }
    }
}
