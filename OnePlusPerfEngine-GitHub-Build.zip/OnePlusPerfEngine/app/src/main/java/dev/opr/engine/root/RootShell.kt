package dev.opr.engine.root

import java.util.concurrent.TimeUnit

data class ShellResult(val code: Int, val out: String, val err: String) { val ok get() = code == 0 }

/** Minimal `su` wrapper. Only invoked after the user explicitly taps a root action; never at startup. */
object RootShell {
    fun exec(cmd: String, timeoutSec: Long = 5): ShellResult = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(false).start()
        val finished = p.waitFor(timeoutSec, TimeUnit.SECONDS)
        if (!finished) { p.destroyForcibly(); ShellResult(-1, "", "timeout") }
        else ShellResult(p.exitValue(), p.inputStream.bufferedReader().readText().trim(), p.errorStream.bufferedReader().readText().trim())
    } catch (t: Throwable) {
        ShellResult(-2, "", t.message ?: "su unavailable")
    }

    fun isRootAvailable(): Boolean = exec("id").let { it.ok && it.out.contains("uid=0") }
}
