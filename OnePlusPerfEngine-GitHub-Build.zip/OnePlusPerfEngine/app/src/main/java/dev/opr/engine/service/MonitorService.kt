package dev.opr.engine.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import dev.opr.engine.collect.SystemCollector
import dev.opr.engine.data.*
import dev.opr.engine.game.*
import dev.opr.engine.root.RootShell
import dev.opr.engine.thermal.*
import kotlinx.coroutines.*

class MonitorService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    private val maxPts = 180
    private val series = LinkedHashMap<String, ArrayDeque<Float>>()
    private val tempHist = HashMap<String, ArrayDeque<Pair<Long, Float>>>()
    private val throttle = ArrayDeque<Int>()
    private val frames = FrameWindow()

    companion object {
        const val ACTION_STOP = "dev.opr.engine.STOP"
        const val EXTRA_GAME_PKG = "game_pkg"
        const val EXTRA_TARGET_FPS = "target_fps"
        @Volatile var gameLayerPolling = false   // set by UI; requires root
        @Volatile var targetFps = 120
        @Volatile var externalFrames: LongArray? = null  // set by UI after user pastes `adb` output
        @Volatile var logToDb = true

        fun start(ctx: Context) = ctx.startForegroundService(Intent(ctx, MonitorService::class.java))
        fun stop(ctx: Context) = ctx.stopService(Intent(ctx, MonitorService::class.java))
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mon", "Hardware monitoring", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0, Intent(this, MonitorService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "mon")
            .setContentTitle("OPR monitoring active")
            .setContentText("Reading CPU / GPU / thermal / battery telemetry (read-only)")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .addAction(Notification.Action.Builder(null, "Stop", stopPi).build())
            .setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        if (job == null) job = scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        val collector = SystemCollector(applicationContext)
        val store = ThresholdStore(applicationContext)
        val dao = AppDb.get(applicationContext).samples()
        val tag = "s" + System.currentTimeMillis()
        var tick = 0
        MetricsHub.state.value = MetricsHub.state.value.copy(running = true, sessionTag = tag)
        while (currentCoroutineContext().isActive) {
            val s = collector.collect()
            tick++
            push("ram", s.memory.usedPct.valueOrNull())
            push("gpuMhz", s.gpu.curHz.valueOrNull()?.let { it / 1e6f })
            s.cpu.policies.forEach { p -> push("cpu${p.id}Mhz", p.curKhz.valueOrNull()?.let { it / 1000f }) }
            val hot = HealthEvaluator.hottestByClass(s)
            ThermalClass.values().forEach { c -> hot[c]?.let { push("t_${c.name}", it); recordTemp(c.name, s.tsMs, it) } }
            throttle.addLast(s.thermal.osStatus.valueOrNull() ?: 0); while (throttle.size > maxPts) throttle.removeFirst()

            if (gameLayerPolling && RootShell.isRootAvailable()) pollSurfaceFlinger()
            externalFrames?.let { frames.clear(); frames.add(it); externalFrames = null }
            val fs = FrameStatsAnalyzer.analyze(frames.snapshot(), targetFps)
            fs?.let { push("fps", it.avgFps.toFloat()); push("fps1", it.onePctLowFps.toFloat()) }

            val trends = tempHist.mapNotNull { (k, v) -> HealthEvaluator.slopeCPerMin(v.takeLast(60).toList())?.let { k to it } }.toMap()
            val warnings = HealthEvaluator.evaluate(s, store.load(), trends)
            val level = HealthEvaluator.overall(warnings)
            val bn = BottleneckDetector.detect(fs, s)
            val (score, basis) = perfScore(s, fs)

            MetricsHub.state.value = HubState(
                running = true, snapshot = s, warnings = warnings, level = level,
                series = series.mapValues { it.value.toList() }, frameStats = fs,
                frameSource = if (frames.snapshot().isNotEmpty()) "SurfaceFlinger present timestamps" else "none",
                bottleneck = bn, perfScore = score, perfScoreBasis = basis,
                throttleTimeline = throttle.toList(), sessionTag = tag,
            )
            if (logToDb && tick % 5 == 0) {
                val cpuHot = hot[ThermalClass.CPU]; val gpuHot = hot[ThermalClass.GPU]
                dao.insert(SampleEntity(
                    tsMs = s.tsMs, sessionTag = tag,
                    cpuCeilingReductionMaxPct = s.cpu.policies.mapNotNull { it.ceilingReductionPct }.maxOrNull(),
                    cpuPrimeMhz = s.cpu.policies.lastOrNull()?.curKhz?.valueOrNull()?.div(1000)?.toInt(),
                    hottestCpuC = cpuHot, hottestGpuC = gpuHot, batteryC = s.battery.tempC.valueOrNull(),
                    batteryMv = s.battery.voltageMv.valueOrNull(), batteryUa = s.battery.currentUa.valueOrNull(),
                    ramUsedPct = s.memory.usedPct.valueOrNull(), osThermalStatus = s.thermal.osStatus.valueOrNull(),
                    avgFps = fs?.avgFps?.toFloat(), onePctLowFps = fs?.onePctLowFps?.toFloat(), level = level.name,
                ))
                if (tick % 600 == 0) dao.prune(System.currentTimeMillis() - 7L * 24 * 3600 * 1000)
            }
            delay(1000)
        }
    }


    private fun recordTemp(k: String, ts: Long, v: Float) {
        val d = tempHist.getOrPut(k) { ArrayDeque() }
        d.addLast(ts to v); while (d.size > 120) d.removeFirst()
    }

    private fun push(k: String, v: Float?) {
        if (v == null) return
        val d = series.getOrPut(k) { ArrayDeque() }
        d.addLast(v); while (d.size > maxPts) d.removeFirst()
    }

    /** Root-only: find the game's layer and read its present timestamps. Read-only dumpsys call. */
    private fun pollSurfaceFlinger() {
        val layers = RootShell.exec("dumpsys SurfaceFlinger --list").out.lines()
        val layer = layers.firstOrNull { it.contains("com.pubg.imobile") && it.contains("SurfaceView") }
            ?: layers.firstOrNull { it.contains("com.pubg.imobile") } ?: return
        val safe = layer.replace("'", "'\\''")
        val out = RootShell.exec("dumpsys SurfaceFlinger --latency '$safe'").out
        SurfaceFlingerLatencyParser.parse(out)?.let { frames.add(it.presentNs) }
    }

    /**
     * Composite 0-100 ESTIMATE of how much of the hardware's potential is currently available:
     *   start 100; subtract ceiling reduction (max across clusters); subtract 10/20/35 for OS thermal MODERATE/SEVERE/CRITICAL+;
     *   subtract (1 - stability%) * 0.3 when frame data exists.
     * It is a relative indicator for comparing runs on this device, not a benchmark score.
     */
    private fun perfScore(s: SystemSnapshot, fs: FrameStats?): Pair<Int, String> {
        var score = 100f
        score -= s.cpu.policies.mapNotNull { it.ceilingReductionPct }.maxOrNull() ?: 0f
        score -= when (s.thermal.osStatus.valueOrNull() ?: 0) { 2 -> 10f; 3 -> 20f; in 4..6 -> 35f; else -> 0f }
        fs?.let { score -= (100f - it.stabilityPct.toFloat()) * 0.3f }
        return score.coerceIn(0f, 100f).toInt() to "ESTIMATE: 100 − ceiling reduction − OS thermal penalty − frame-pacing penalty"
    }

    override fun onDestroy() {
        scope.cancel()
        MetricsHub.state.value = MetricsHub.state.value.copy(running = false)
        super.onDestroy()
    }
}
