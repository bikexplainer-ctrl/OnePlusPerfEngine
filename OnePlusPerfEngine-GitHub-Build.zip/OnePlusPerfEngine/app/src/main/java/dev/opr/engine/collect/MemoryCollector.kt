package dev.opr.engine.collect

import android.app.ActivityManager
import android.content.Context
import dev.opr.engine.data.*

class MemoryCollector(ctx: Context) {
    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun collect(): MemorySnapshot {
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val src = "ActivityManager.getMemoryInfo"
        val totalMb = mi.totalMem / 1048576
        val availMb = mi.availMem / 1048576
        // /proc/pressure/memory: "some avg10=0.00 avg60=... total=..." — usually SELinux-blocked for apps.
        val psi: Reading<Float> = Sysfs.read("/proc/pressure/memory")?.let { s ->
            Regex("some avg10=([0-9.]+)").find(s)?.groupValues?.get(1)?.toFloatOrNull()
                ?.let { Reading.Actual(it, "/proc/pressure/memory some avg10 (%)") }
        } ?: Reading.Inaccessible("PSI not readable by this app (use adb shell cat /proc/pressure/memory)")
        return MemorySnapshot(
            totalMb = Reading.Actual(totalMb, src),
            availMb = Reading.Actual(availMb, src),
            usedPct = Reading.Actual(100f * (1f - mi.availMem.toFloat() / mi.totalMem), "$src (derived from avail/total)"),
            lowMemory = Reading.Actual(mi.lowMemory, "$src.lowMemory (threshold ${mi.threshold / 1048576} MB)"),
            psiSomeAvg10 = psi,
        )
    }
}
