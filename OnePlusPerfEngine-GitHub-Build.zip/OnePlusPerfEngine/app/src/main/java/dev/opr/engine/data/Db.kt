package dev.opr.engine.data

import android.content.Context
import androidx.room.*

@Entity(tableName = "samples", indices = [Index("tsMs")])
data class SampleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tsMs: Long,
    val sessionTag: String,
    val cpuCeilingReductionMaxPct: Float?,
    val cpuPrimeMhz: Int?,
    val hottestCpuC: Float?,
    val hottestGpuC: Float?,
    val batteryC: Float?,
    val batteryMv: Int?,
    val batteryUa: Long?,
    val ramUsedPct: Float?,
    val osThermalStatus: Int?,
    val avgFps: Float?,
    val onePctLowFps: Float?,
    val level: String,
)

@Dao
interface SampleDao {
    @Insert suspend fun insert(s: SampleEntity)
    @Query("SELECT * FROM samples ORDER BY tsMs DESC LIMIT :n") suspend fun recent(n: Int): List<SampleEntity>
    @Query("SELECT * FROM samples WHERE sessionTag = :tag ORDER BY tsMs ASC") suspend fun session(tag: String): List<SampleEntity>
    @Query("DELETE FROM samples WHERE tsMs < :cutoff") suspend fun prune(cutoff: Long)
}

@Database(entities = [SampleEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun samples(): SampleDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "metrics.db").build().also { inst = it }
        }
    }
}
