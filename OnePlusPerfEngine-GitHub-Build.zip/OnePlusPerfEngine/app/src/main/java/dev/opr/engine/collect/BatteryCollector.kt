package dev.opr.engine.collect

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import dev.opr.engine.data.*

class BatteryCollector(private val ctx: Context) {
    private val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    fun collect(): BatterySnapshot {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val src = "ACTION_BATTERY_CHANGED"
        val tempC: Reading<Float> = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            ?.takeIf { it != Int.MIN_VALUE }?.let { Reading.Actual(it / 10f, "$src.EXTRA_TEMPERATURE") }
            ?: Reading.Inaccessible("no battery intent")
        val mv: Reading<Int> = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
            ?.takeIf { it > 0 }?.let { Reading.Actual(it, "$src.EXTRA_VOLTAGE") }
            ?: Reading.Inaccessible("no voltage")
        val healthCode = i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0) ?: 0
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val ua = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        // CURRENT_NOW: Android documents positive = charging, but OEM drivers differ; value is shown as reported.
        val cur: Reading<Long> = if (ua != Long.MIN_VALUE && ua != 0L)
            Reading.Actual(ua, "BatteryManager.BATTERY_PROPERTY_CURRENT_NOW (µA; sign is OEM-dependent)")
        else Reading.Inaccessible("CURRENT_NOW returned 0/unsupported")
        val power: Reading<Float> = run {
            val v = mv.valueOrNull(); val c = cur.valueOrNull()
            if (v != null && c != null) Reading.Estimate(v / 1000f * (kotlin.math.abs(c) / 1000f),
                "|V|×|I| from two ACTUAL readings; not a rail-level measurement")
            else Reading.Inaccessible("needs both voltage and current")
        }
        val cycles: Reading<Int> = try {
            val c = i?.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1) ?: -1
            if (c >= 0) Reading.Actual(c, "$src.EXTRA_CYCLE_COUNT") else Reading.Inaccessible("cycle count not exposed")
        } catch (t: Throwable) { Reading.Inaccessible("cycle count not exposed") }

        val paths = listOf("/sys/class/power_supply/battery/charge_full", "/sys/class/power_supply/battery/charge_full_design")
        val r = Sysfs.readAll(paths)
        val full = r[0]?.trim()?.toDoubleOrNull(); val design = r[1]?.trim()?.toDoubleOrNull()
        val cap: Reading<Float> = if (full != null && design != null && design > 0)
            Reading.Estimate((full / design * 100).toFloat(), "charge_full / charge_full_design (sysfs); reflects driver-learned capacity")
        else Reading.Inaccessible("charge_full/_design not readable by this app")

        return BatterySnapshot(
            tempC = tempC, voltageMv = mv, currentUa = cur, powerMw = power,
            levelPct = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)?.takeIf { it >= 0 }
                ?.let { Reading.Actual(it, "$src.EXTRA_LEVEL") } ?: Reading.Inaccessible("no level"),
            charging = Reading.Actual(status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL, "$src.EXTRA_STATUS"),
            health = Reading.Actual(healthName(healthCode), "$src.EXTRA_HEALTH"),
            healthIsOverheat = healthCode == BatteryManager.BATTERY_HEALTH_OVERHEAT,
            cycleCount = cycles, capacityHealthPct = cap,
        )
    }

    private fun healthName(h: Int) = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "GOOD"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "OVERHEAT"
        BatteryManager.BATTERY_HEALTH_DEAD -> "DEAD"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "OVER_VOLTAGE"
        BatteryManager.BATTERY_HEALTH_COLD -> "COLD"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "FAILURE"
        else -> "UNKNOWN"
    }
}
