package dev.opr.engine.thermal

import dev.opr.engine.collect.ThermalCollector
import dev.opr.engine.data.*

enum class Level { GREEN, YELLOW, ORANGE, RED }

data class Warning(
    val level: Level,
    val metric: String,
    val current: String,
    /** "UNKNOWN" unless a verified or user-set limit exists. */
    val referenceLimit: String,
    val difference: String,
    val consequences: String,
    val action: String,
)

/** Per-class user-defined temperature thresholds (°C). null = not set. These are USER-SET, never presented as verified. */
data class ClassThresholds(val yellow: Float? = null, val orange: Float? = null, val red: Float? = null)
data class Thresholds(
    val byClass: Map<ThermalClass, ClassThresholds> = emptyMap(),
    /** Rise rate (°C/min) above which load is called "increasing". A trend heuristic, not a safety limit. */
    val risingCPerMin: Float = 3f,
)

/**
 * Verified component limits registry.
 * Intentionally empty: no manufacturer-published, per-component temperature limit for the OnePlus 15R's SoC, GPU or
 * battery was verified while building this project, so every entry is UNKNOWN. Add an entry only with a citation.
 */
object VerifiedLimits {
    data class Limit(val classKey: ThermalClass, val valueC: Float, val citation: String)
    val entries: List<Limit> = emptyList()
    fun forClass(c: ThermalClass): Limit? = entries.firstOrNull { it.classKey == c }
}

object HealthEvaluator {

    /** @param trendsCPerMin keyed by "BATTERY", "CPU", "GPU", "SKIN" -> slope over the recent window. */
    fun evaluate(s: SystemSnapshot, th: Thresholds, trendsCPerMin: Map<String, Float>): List<Warning> {
        val out = mutableListOf<Warning>()

        // 1. Android's own thermal status (OS/firmware-defined levels).
        val st = s.thermal.osStatus.valueOrNull() ?: 0
        if (st >= 1) {
            val lvl = when (st) { 1 -> Level.YELLOW; 2, 3 -> Level.ORANGE; else -> Level.RED }
            out += Warning(
                lvl, "OS thermal status", ThermalCollector.statusName(st),
                "Android ThermalStatus scale (OS-defined; per-sensor °C trip points are not exposed to apps)",
                "n/a",
                when (lvl) {
                    Level.YELLOW -> "Light throttling; UX normally unaffected."
                    Level.ORANGE -> "Frequency/brightness caps active; frame rate and touch response may degrade."
                    else -> "Platform is shedding power aggressively; components may shut down (EMERGENCY/SHUTDOWN)."
                },
                if (lvl == Level.RED) "Stop the workload now, remove case, let the device cool."
                else "Lower in-game graphics/FPS cap, stop charging during play, improve ventilation."
            )
        }

        // 2. Frequency ceilings lowered below hardware max (software/firmware-imposed).
        for (p in s.cpu.policies) {
            val red = p.ceilingReductionPct ?: continue
            if (red >= 5f) {
                val lvl = if (red >= 20f) Level.ORANGE else Level.YELLOW
                out += Warning(
                    lvl, "CPU policy${p.id} frequency ceiling",
                    "${p.scalingMaxKhz.valueOrNull()?.div(1000)} MHz",
                    "${p.hwMaxKhz.valueOrNull()?.div(1000)} MHz (cpuinfo_max_freq; performance reference, not a safety limit)",
                    "-%.1f%%".format(red),
                    "Reduced peak CPU throughput; cause may be thermal, battery saver, or vendor game/perf profile.",
                    "Check Thermal tab; if temps are normal the cap is a vendor power policy (see Analysis > restrictions).",
                )
            }
        }

        // 3. Battery overheat flag reported by the charger/fuel-gauge firmware.
        if (s.battery.healthIsOverheat) {
            out += Warning(
                Level.RED, "Battery health flag", "OVERHEAT",
                "Fuel-gauge/charger firmware flag via BatteryManager (trip point not exposed)", "n/a",
                "Accelerated cell degradation; firmware may stop charging or shut down.",
                "Stop intensive workloads, unplug charger, allow cooling."
            )
        }

        // 4. User-defined per-class thresholds (and verified limits when present).
        val hottest = hottestByClass(s)
        for ((cls, tempC) in hottest) {
            val verified = VerifiedLimits.forClass(cls)
            val user = th.byClass[cls]
            var lvl = Level.GREEN
            var ref = "UNKNOWN"
            var diff = "UNKNOWN"
            if (verified != null) {
                ref = "%.1f °C (verified: %s)".format(verified.valueC, verified.citation)
                diff = "%+.1f °C".format(tempC - verified.valueC)
                if (tempC >= verified.valueC) lvl = Level.RED
                else if (tempC >= verified.valueC - 5f) lvl = Level.ORANGE
            }
            if (user != null) {
                val l = when {
                    user.red != null && tempC >= user.red -> Level.RED
                    user.orange != null && tempC >= user.orange -> Level.ORANGE
                    user.yellow != null && tempC >= user.yellow -> Level.YELLOW
                    else -> Level.GREEN
                }
                if (verified == null && (user.red ?: user.orange ?: user.yellow) != null) {
                    val r = user.red ?: user.orange ?: user.yellow!!
                    ref = "%.1f °C (USER-SET, unverified)".format(r)
                    diff = "%+.1f °C".format(tempC - r)
                }
                if (l > lvl) lvl = l
            }
            if (lvl != Level.GREEN) out += Warning(
                lvl, "${cls.name} temperature", "%.1f °C".format(tempC), ref, diff,
                "Sustained high temperature accelerates wear and triggers throttling; true damage threshold is UNKNOWN for this component.",
                if (lvl == Level.RED) "Stop intensive workloads and let the device cool." else "Reduce load or improve cooling."
            )
        }

        // 5. Rising trend.
        for ((k, v) in trendsCPerMin) {
            if (v >= th.risingCPerMin) out += Warning(
                Level.YELLOW, "$k temperature trend", "+%.1f °C/min".format(v),
                "UNKNOWN (trend threshold ${th.risingCPerMin} °C/min is a configurable heuristic)", "n/a",
                "Thermal load is increasing; throttling is likely if this continues.",
                "Plan to reduce FPS cap or take a break before the OS does it for you."
            )
        }

        // 6. Memory.
        if (s.memory.lowMemory.valueOrNull() == true) out += Warning(
            Level.YELLOW, "RAM", "lowMemory=true", "ActivityManager low-memory threshold", "n/a",
            "Background apps are killed, game may reload assets or stutter.", "Close heavy background apps manually."
        )
        return out
    }

    fun overall(w: List<Warning>): Level = w.maxOfOrNull { it.level } ?: Level.GREEN

    /** Hottest reading per inferred class; battery temp from BatteryManager overrides zone inference for BATTERY. */
    fun hottestByClass(s: SystemSnapshot): Map<ThermalClass, Float> {
        val m = HashMap<ThermalClass, Float>()
        for (z in s.thermal.zones) {
            val t = z.tempC.valueOrNull() ?: continue
            if (z.cls == ThermalClass.OTHER) continue
            if (t > (m[z.cls] ?: Float.NEGATIVE_INFINITY)) m[z.cls] = t
        }
        s.battery.tempC.valueOrNull()?.let { m[ThermalClass.BATTERY] = it }
        s.gpu.tempC.valueOrNull()?.let { if (it > (m[ThermalClass.GPU] ?: -1e9f)) m[ThermalClass.GPU] = it }
        return m
    }

    /** Least-squares slope in °C/min over (tMs, °C) samples. */
    fun slopeCPerMin(samples: List<Pair<Long, Float>>): Float? {
        if (samples.size < 10) return null
        val t0 = samples.first().first
        val xs = samples.map { (it.first - t0) / 60000.0 }
        val ys = samples.map { it.second.toDouble() }
        val mx = xs.average(); val my = ys.average()
        val den = xs.sumOf { (it - mx) * (it - mx) }
        if (den <= 0.0) return null
        return (xs.indices.sumOf { (xs[it] - mx) * (ys[it] - my) } / den).toFloat()
    }
}
