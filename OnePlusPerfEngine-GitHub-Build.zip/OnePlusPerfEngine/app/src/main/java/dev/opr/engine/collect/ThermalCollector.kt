package dev.opr.engine.collect

import android.content.Context
import android.os.Build
import android.os.PowerManager
import dev.opr.engine.data.*

class ThermalCollector(ctx: Context) {
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    private var lastHeadroomMs = 0L
    private var lastHeadroom: Reading<Float> = Reading.Inaccessible("not sampled yet")
    private val root = "/sys/class/thermal"

    fun collect(nowMs: Long): ThermalSnapshot {
        val zoneDirs = Sysfs.list(root).filter { it.startsWith("thermal_zone") }
            .sortedBy { it.removePrefix("thermal_zone").toIntOrNull() ?: 0 }
        val types = Sysfs.readAll(zoneDirs.map { "$root/$it/type" })
        val temps = Sysfs.readAll(zoneDirs.map { "$root/$it/temp" })
        val zones = zoneDirs.mapIndexed { i, d ->
            val type = types[i] ?: "unknown"
            val t = temps[i]?.trim()?.toFloatOrNull()
            ThermalZone(
                id = d.removePrefix("thermal_zone").toIntOrNull() ?: -1,
                type = type,
                // Kernel reports millidegrees on virtually all devices; values already in degrees are kept as is.
                tempC = if (t != null) Reading.Actual(if (kotlin.math.abs(t) >= 1000f) t / 1000f else t, "$root/$d/temp")
                else Reading.Inaccessible("zone temp unreadable (blocked by SELinux for apps or absent)"),
                cls = classify(type),
            )
        }
        if (nowMs - lastHeadroomMs >= 5_000) {  // getThermalHeadroom is rate-limited by the platform
            lastHeadroomMs = nowMs
            lastHeadroom = try {
                val h = pm.getThermalHeadroom(10)
                if (h.isNaN()) Reading.Inaccessible("device does not provide thermal headroom")
                else Reading.Actual(h, "PowerManager.getThermalHeadroom(10s) (1.0 = SEVERE throttling threshold)")
            } catch (t: Throwable) {
                Reading.Inaccessible("getThermalHeadroom failed: ${t.javaClass.simpleName}")
            }
        }
        return ThermalSnapshot(
            zones = zones,
            osStatus = Reading.Actual(pm.currentThermalStatus, "PowerManager.getCurrentThermalStatus"),
            headroom = lastHeadroom,
        )
    }

    companion object {
        fun classify(type: String): ThermalClass {
            val t = type.lowercase()
            return when {
                Regex("gpu").containsMatchIn(t) -> ThermalClass.GPU
                Regex("batt|bms|charger").containsMatchIn(t) -> ThermalClass.BATTERY
                Regex("skin|quiet|xo.?therm|shell|case|back|front").containsMatchIn(t) -> ThermalClass.SKIN
                Regex("cpu|cpuss|gold|prime|silver|cluster").containsMatchIn(t) -> ThermalClass.CPU
                else -> ThermalClass.OTHER
            }
        }

        fun statusName(s: Int) = when (s) {
            0 -> "NONE"; 1 -> "LIGHT"; 2 -> "MODERATE"; 3 -> "SEVERE"
            4 -> "CRITICAL"; 5 -> "EMERGENCY"; 6 -> "SHUTDOWN"; else -> "UNKNOWN($s)"
        }
    }
}
