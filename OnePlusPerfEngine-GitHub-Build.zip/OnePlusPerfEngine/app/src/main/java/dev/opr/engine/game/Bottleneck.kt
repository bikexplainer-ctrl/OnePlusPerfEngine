package dev.opr.engine.game

import dev.opr.engine.data.*
import dev.opr.engine.thermal.Level

enum class BottleneckKind { NONE, THERMAL, GPU_BOUND, CPU_BOUND, MEMORY, UNDETERMINED }

/** All bottleneck results are ESTIMATES (heuristics over measured inputs). Evidence lists the inputs used. */
data class Bottleneck(val kind: BottleneckKind, val evidence: List<String>)

object BottleneckDetector {

    fun detect(fs: FrameStats?, s: SystemSnapshot): Bottleneck {
        if (fs == null) return Bottleneck(BottleneckKind.UNDETERMINED, listOf("No frame data yet (see Game tab for sources)."))
        val shortfall = fs.avgFps < fs.targetFps * 0.95 || fs.onePctLowFps < fs.targetFps * 0.6 || fs.dropPct > 5.0
        if (!shortfall) return Bottleneck(BottleneckKind.NONE, listOf("Frame pacing meets target within tolerance."))

        val ev = mutableListOf("avg %.0f fps / 1%% low %.0f fps vs target %d".format(fs.avgFps, fs.onePctLowFps, fs.targetFps))

        val osStatus = s.thermal.osStatus.valueOrNull() ?: 0
        val maxCap = s.cpu.policies.mapNotNull { it.ceilingReductionPct }.maxOrNull() ?: 0f
        if (osStatus >= 2 || maxCap >= 10f) {
            ev += "OS thermal status=$osStatus, largest CPU ceiling reduction=%.0f%%".format(maxCap)
            return Bottleneck(BottleneckKind.THERMAL, ev)
        }
        if (s.memory.lowMemory.valueOrNull() == true || (s.memory.psiSomeAvg10.valueOrNull() ?: 0f) > 10f) {
            ev += "Memory pressure reported"
            return Bottleneck(BottleneckKind.MEMORY, ev)
        }
        val gpuBusy = s.gpu.busyPct.valueOrNull()
        if (gpuBusy != null && gpuBusy >= 90f) {
            ev += "GPU busy %.0f%% (ACTUAL kgsl)".format(gpuBusy)
            return Bottleneck(BottleneckKind.GPU_BOUND, ev)
        }
        val utils = s.cpu.cores.mapNotNull { it.utilPct.valueOrNull() }
        if (utils.isNotEmpty()) {
            val hot = utils.count { it >= 90f }
            if (hot in 1..3 || utils.average() >= 80.0) {
                ev += "$hot core(s) ≥90%% busy, mean %.0f%%".format(utils.average())
                return Bottleneck(BottleneckKind.CPU_BOUND, ev)
            }
        } else ev += "CPU utilisation unavailable (needs adb/root)"
        if (gpuBusy == null) ev += "GPU utilisation unavailable (needs adb/root)"
        return Bottleneck(BottleneckKind.UNDETERMINED, ev + "No single limiter identified from accessible metrics.")
    }
}

/**
 * Non-invasive advice for sustained 120 fps. Nothing here touches game files, memory, or anti-cheat;
 * it only reads telemetry and tells the user which supported settings to change.
 */
object GamingProfile {
    fun advise(fs: FrameStats?, b: Bottleneck, level: Level): List<String> {
        val tips = mutableListOf<String>()
        if (fs != null && fs.targetFps >= 100 && (b.kind == BottleneckKind.THERMAL || level >= Level.ORANGE)) {
            tips += "Sustained 120 isn't holding. A locked 90 fps usually gives better frame-time consistency than 120 with throttling dips. Test it with the same benchmark run."
        }
        if (fs != null && fs.stabilityPct < 90) tips += "Frame pacing is uneven (%.0f%% in-target). Try the in-game FPS/graphics preset one step lower and compare 1%% lows.".format(fs.stabilityPct)
        tips += "Disable battery saver; use OxygenOS Game Mode / Gaming Assistant performance settings (supported, user-controlled)."
        tips += "Avoid charging while gaming if the Thermal tab shows battery temperature climbing; charging adds heat."
        tips += "Remove thick cases; keep ambient temperature low. These change sustained results more than any software toggle."
        tips += "Close heavy background apps before the match (manual; this app does not 'clean RAM')."
        when (b.kind) {
            BottleneckKind.GPU_BOUND -> tips += "GPU-bound: lower resolution/graphics style; CPU tweaks won't help."
            BottleneckKind.CPU_BOUND -> tips += "CPU-bound: lower player/effects/shadows settings; GPU settings won't help."
            BottleneckKind.MEMORY -> tips += "Memory-limited: close background apps and restart the game."
            else -> {}
        }
        return tips
    }
}
